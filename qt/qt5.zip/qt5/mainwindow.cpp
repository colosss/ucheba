#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->lineEdit, &QLineEdit::textChanged, this,&MainWindow::on_lineEdit_textChanged);
    connect(ui->lineEdit_2, &QLineEdit::textChanged, this, &MainWindow::on_lineEdit_textChanged);
    connect(ui->lineEdit_3, &QLineEdit::textChanged, this, &MainWindow::on_lineEdit_textChanged);
    connect(ui->pushButton_con_1, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_con_2, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_con_3, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_prog_1, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_prog_2, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_prog_3, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_hard_1, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_hard_2, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_hard_3, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_my_1, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);
    connect(ui->pushButton_my_2, &QPushButton::released, this, &MainWindow::on_pushButton_con_2_released);

    ui->pushButton_con_1->setDisabled(true);
    ui->pushButton_con_2->setDisabled(true);
    ui->pushButton_con_3->setDisabled(true);
    ui->pushButton_hard_2->setDisabled(true);
    ui->pushButton_hard_3->setDisabled(true);
    ui->pushButton_my_1->setDisabled(true);
    ui->pushButton_my_2->setDisabled(true);
    ui->pushButton_prog_1->setDisabled(true);
    ui->pushButton_prog_2->setDisabled(true);
    ui->pushButton_prog_3->setDisabled(true);
    ui->lineEdit->setDisabled(true);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{
    if(ui->lineEdit->text().isEmpty()){
        ui->pushButton_con_1->setDisabled(true);
        ui->pushButton_con_2->setDisabled(true);
    }
    else{
        ui->pushButton_con_1->setDisabled(false);
        ui->pushButton_con_2->setDisabled(false);
    }
}

void MainWindow::on_pushButton_con_2_released()
{

}

void MainWindow::on_pushButton_con_1_released()
{

}

void MainWindow::on_lineEdit_2_textChanged(const QString &arg1)
{
    if (ui->lineEdit_2->text().isEmpty()){
        ui->pushButton_prog_1->setDisabled(true);
        ui->pushButton_con_3->setDisabled(true);
    }
    else{
        ui->pushButton_prog_1->setDisabled(false);
        if(!list_ishod.isEmpty()){
            ui->pushButton_con_3->setDisabled(false);
        }
    }
}


void MainWindow::on_pushButton_hard_1_released()
{
    QString temp_file_name=ui->comboBox_file_name->currentText();
    QFile file("/home/mifugi/ucheba/qt/qt5/"+temp_file_name);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл!");
        return;
    }

    QTextStream in (&file);
    while(!in.atEnd()){
        QString line = in.readLine();
        list_ishod.append(line.toInt());
        qDebug()<<line;
    }

    QString temp_list="";
    for (const int &str : list_ishod){
        // temp_list+=QString::number(str);
        ui->listWidget_ishod->addItem(QString::number(str));
    }
    // ui->textBrowser_ishod->setText(temp_list);
    if(!ui->lineEdit_2->text().isEmpty()){
        ui->pushButton_con_3->setDisabled(false);
    }
    if (!list_ishod.isEmpty()){
        ui->lineEdit->setDisabled(false);
        ui->pushButton_my_1->setDisabled(false);
        ui->pushButton_my_2->setDisabled(false);
        ui->pushButton_hard_2->setDisabled(false);
        ui->pushButton_hard_3->setDisabled(false);
        ui->pushButton_prog_2->setDisabled(false);
        ui->pushButton_prog_3->setDisabled(false);
    }


    file.close();
}


void MainWindow::on_pushButton_hard_2_released()
{
    QString temp_file_name=ui->comboBox_file_name->currentText();
    QFile file("/home/mifugi/ucheba/qt/qt5/modify_"+temp_file_name);

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text)){
        QMessageBox::warning(this, "Ошибка", "Не удалось записать в файл!");
        return;
    }

    QTextStream out(&file);

    for (const int &str : list_modify){
        out<<str;
    }
    file.close();
}


void MainWindow::on_textBrowser_ishod_textChanged()
{
}

void MainWindow::on_listWidget_ishod_itemSelectionChanged()
{
}

void MainWindow::show_element_by_id(){
    QString temp_str=ui->lineEdit->text();
    if(!temp_str.isEmpty()){
        QString temp_num=0;
        if(temp_str.toInt()<=list_ishod.size()){
            qsizetype temp_count=2;
            temp_num=list_ishod.value(temp_count);
            ui->lineEdit_3->setText(temp_num);
        }
        else{
            QMessageBox::warning(this, "Ошибка", "Индекс больше размера коллекции!");
            return;
        }

    }
}
